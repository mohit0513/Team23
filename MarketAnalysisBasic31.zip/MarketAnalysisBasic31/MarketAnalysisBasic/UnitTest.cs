﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MarketAnalysisBasic
{
   public class UnitTest
    {
        StockDetails stock = new StockDetails("ticker");
       // Assert.AreEqual(stock.ticker,"ticker");


    }
}
