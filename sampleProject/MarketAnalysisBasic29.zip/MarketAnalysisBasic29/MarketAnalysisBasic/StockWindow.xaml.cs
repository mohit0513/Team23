﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MarketAnalysisBasic
{
    /// <summary>
    /// Interaction logic for StockWindow.xaml
    /// </summary>
    public partial class StockWindow : Window
    {
        public StockWindow()
        {
            InitializeComponent();
        }

        private void listBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ShowCharts(object sender, RoutedEventArgs e)
        {
            // Show Graphs,Histograms,Tables
            if(stockList.Contains)
        }

        private void ShowTradeSnapshot(object sender, RoutedEventArgs e)
        {
           // MessageBox.Show(Stock.Tostring());
        }

        private void ShowCompanyInformation(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show(company.Tostring());
        }

        private void PeerComparison(object sender, RoutedEventArgs e)
        {
            PeerComparison stockComparison = new PeerComparison();
            stockComparison.Show();
        }

        private void LastNumberOfDays(object sender, RoutedEventArgs e)
        {
            comboSelectRange.Items.Add("7 Days");
            comboSelectRange.Items.Add("2 Weeks");
            comboSelectRange.Items.Add("30 Days");
            comboSelectRange.Items.Add("6 Months");
            comboSelectRange.Items.Add("1 Years");
            comboSelectRange.Items.Add("5 Years");
            comboSelectRange.Items.Add("10 Years");
        }
    }
}
