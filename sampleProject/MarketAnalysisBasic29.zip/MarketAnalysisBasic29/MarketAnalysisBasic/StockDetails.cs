﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;

namespace MarketAnalysisBasic
{

    enum StockSegment
    {
        Automotive,
        BankingAndFinancialServices,
        Telecommunication,
        InformationTechnology,
        Manufacturing,
        FoodAndBeverages,
        OilAndGas,
        Miscallaneous,
        PSU,
        Services,
        MediaAndEntertainment
    };

    enum StockCountry
    {
        India,
        USA,
        UK,
        Germany,
        France,
        Japan,
        China,
        Honkong
    };

    enum StockMarketIndia
    {
        NationalStockExchangeNIFTY,
        BombayStockExchangSENSEX
    };

    enum StockMarketUsa
    {
        NYSE,
        NASDAQ
    };

    enum StockMarketUk
    {
        LondonStockExchange,
        Euronext
    };

    enum StockMarketHonkong
    {
        HongKongStockExchange
    };

    enum StockMarketChina
    {
        ShanghaiStockExchange,
        ShenzhenStockExchange
    };

    enum StockMarketJapan
    {
        JapanExchangeGroupTokyoNIKKEI
    };

    enum StockMarketGermany
    {
        DeutscheBörse,
        BörseMünchen,
        FrankfurtStockExchange
    };

    enum StockMarketFrance
    {
        EuronextParis,
        EuropeanStockExchange
    };

    enum StockExchange
    {
        NationalStockExchangeNIFTY,
        BombayStockExchangeSENSEX,
        NYSE,
        NASDAQ,
        LondonStockExchange,
        Euronext,
        HongKongStockExchange,
        ShanghaiStockExchange,
        ShenzhenStockExchange,
        JapanExchangeGroupTokyoNIKKEI,
        DeutscheBörse,
        BörseMünchen,
        FrankfurtStockExchange,
        EuronextParis,
        EuropeanStockExchange
    };

    enum PerformanceCriterion
    {
        Return,
        Volatility,
        Stability,
        PERatio,
        PBRatio,
        ActivelyTraded,
        MarketCap,
        EPS,
        Revenue
    };


    [DataContract]
    class StockDetails
    {
        [DataMember]
        public string ticker { get; private set; }
        [DataMember]
        public int uniqueStockId { get; private set; }
        [DataMember]
        public double open { get; private set; }
        [DataMember]
        public double close { get; private set; }
        [DataMember]
        public double high { get; private set; }
        [DataMember]
        public double low { get; private set; }
        //[DataMember]
        //public long date1 { get; set; }
        [DataMember]
        public string date { get; set; }
        //[DataMember]
        public DateTime Date { get; set; }
        [DataMember]
        public StockSegment Sector { get; private set; }
        [DataMember]
        public StockCountry Country { get; private set; }
        [DataMember]
        public StockExchange Exchange { get; private set; }
        [DataMember]
        public double ValueWeightedAveragePrice { get; private set; }
        [DataMember]
        public double tradedVolume { get; private set; }
        [DataMember]
        public long TradedPrice { get; private set; }
        [DataMember]
        public long FreeFloatMarketCap { get; private set; }
        [DataMember]
        public double YearHigh { get; private set; }
        [DataMember]
        public double YearLow { get; private set; }
        [DataMember]
        public int BuyQuantity { get; private set; }
        [DataMember]
        public int SellQuantitiy { get; private set; }
        [DataMember]
        public double BuyPrice { get; private set; }
        [DataMember]
        public double SellPrice { get; private set; }
        [DataMember]
        public int day { get; private set; }
        [DataMember]
        public int month { get; private set; }
        [DataMember]
        public int year { get; private set; }

        


        public override string ToString()
        {
            string message ="StockId : " + uniqueStockId +"\nTicker : " + ticker + "\n Date Time : " + date + "\nOpen Price"  + open + "\nClose Price : " + close + "\nHighest IntraDay Price : "
                + high + "\nLowestIntraDay Price : " + low + "\nTraded Volume : " + tradedVolume;
            message += "";

            return message;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            if (obj is StockDetails)
            {
                StockDetails p = obj as StockDetails;
                return Exchange == p.Exchange && ticker == p.ticker;
            }

            return false;
        }

    }
}
