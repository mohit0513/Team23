﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MarketAnalysisBasic
{
    /// <summary>
    /// Interaction logic for SectorWindow.xaml
    /// </summary>
    public partial class SectorWindow : Window
    {
        public SectorWindow()
        {
            InitializeComponent();
        }

        private void Compare(object sender, RoutedEventArgs e)
        {
            comboComapre.Items.Add(StockSegment.Automotive);
            comboComapre.Items.Add(StockSegment.BankingAndFinancialServices);
            comboComapre.Items.Add(StockSegment.FoodAndBeverages);
            comboComapre.Items.Add(StockSegment.InformationTechnology);
            comboComapre.Items.Add(StockSegment.Manufacturing);
            comboComapre.Items.Add(StockSegment.MediaAndEntertainment);
            comboComapre.Items.Add(StockSegment.Miscallaneous);
            comboComapre.Items.Add(StockSegment.OilAndGas);
            comboComapre.Items.Add(StockSegment.PSU);
            comboComapre.Items.Add(StockSegment.Services);
            comboComapre.Items.Add(StockSegment.Telecommunication);
        }

        private void SectorPerformers(object sender, RoutedEventArgs e)
        {
            comboSectorPerformers.Items.Add(PerformanceCriterion.ActivelyTraded);
            comboSectorPerformers.Items.Add(PerformanceCriterion.EPS);
            comboSectorPerformers.Items.Add(PerformanceCriterion.MarketCap);
            comboSectorPerformers.Items.Add(PerformanceCriterion.PBRatio);
            comboSectorPerformers.Items.Add(PerformanceCriterion.PERatio);
            comboSectorPerformers.Items.Add(PerformanceCriterion.Return);
            comboSectorPerformers.Items.Add(PerformanceCriterion.Revenue);
            comboSectorPerformers.Items.Add(PerformanceCriterion.Stability);
            comboSectorPerformers.Items.Add(PerformanceCriterion.Volatility);
        }

        private void LastNumberOfDays(object sender, RoutedEventArgs e)
        {
            comboSelectRange.Items.Add("7 Days");
            comboSelectRange.Items.Add("2 Weeks");
            comboSelectRange.Items.Add("30 Days");
            comboSelectRange.Items.Add("6 Months");
            comboSelectRange.Items.Add("1 Years");
            comboSelectRange.Items.Add("5 Years");
            comboSelectRange.Items.Add("10 Years");
        }

        private void CompareSectorPerformance(object sender, ContextMenuEventArgs e)
        {
            //// Compare the performance of the 2 sectors over a certain range of time
            // Also Plot the graph.
        }

        private void ShowTopPerformers(object sender, RoutedEventArgs e)
        {
            // Show the top stocks corresponding to the selected criteria.
        }
    }
}
