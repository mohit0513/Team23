﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MarketAnalysisBasic
{
    /// <summary>
    /// Interaction logic for StockExchangeWindow.xaml
    /// </summary>
    public partial class StockExchangeWindow : Window
    {
        public StockExchangeWindow()
        {
            InitializeComponent();
        }

        private void ExchangePerformers(object sender, RoutedEventArgs e)
        {
            comboExchangePerformers.Items.Add(PerformanceCriterion.ActivelyTraded);
            comboExchangePerformers.Items.Add(PerformanceCriterion.EPS);
            comboExchangePerformers.Items.Add(PerformanceCriterion.MarketCap);
            comboExchangePerformers.Items.Add(PerformanceCriterion.PBRatio);
            comboExchangePerformers.Items.Add(PerformanceCriterion.PERatio);
            comboExchangePerformers.Items.Add(PerformanceCriterion.Return);
            comboExchangePerformers.Items.Add(PerformanceCriterion.Revenue);
            comboExchangePerformers.Items.Add(PerformanceCriterion.Stability);
            comboExchangePerformers.Items.Add(PerformanceCriterion.Volatility);
        }

        private void LastNumberOfDays(object sender, RoutedEventArgs e)
        {
            comboSelectRange.Items.Add("7 Days");
            comboSelectRange.Items.Add("2 Weeks");
            comboSelectRange.Items.Add("30 Days");
            comboSelectRange.Items.Add("6 Months");
            comboSelectRange.Items.Add("1 Years");
            comboSelectRange.Items.Add("5 Years");
            comboSelectRange.Items.Add("10 Years");
            //comboSelectRange.Items.Add((int)7);

        }

        private void ShowExchangePerformance(object sender, RoutedEventArgs e)
        {
            // Compare the performance of the 2 stock exchanges over a certain range of time
            // Also Plot the graph.
        }

        private void ShowTopPerformers(object sender, RoutedEventArgs e)
        {
            // Show the top stocks corresponding to the selected criteria.
        }

        private void FillCountry(object sender, RoutedEventArgs e)
        {
            comboCountry.Items.Add(StockCountry.China);
            comboCountry.Items.Add(StockCountry.France);
            comboCountry.Items.Add(StockCountry.Germany);
            comboCountry.Items.Add(StockCountry.Honkong);
            comboCountry.Items.Add(StockCountry.India);
            comboCountry.Items.Add(StockCountry.Japan);
            comboCountry.Items.Add(StockCountry.UK);
            comboCountry.Items.Add(StockCountry.USA);
        }

        private void UpdateStockExchange(object sender, SelectionChangedEventArgs e)
        {
            if (comboCountry.SelectedIndex == 4)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.BombayStockExchangeSENSEX);
                comboStockExchange.Items.Add(StockExchange.NationalStockExchangeNIFTY);
            }

            else if (comboCountry.SelectedIndex == 2)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.BörseMünchen);
                comboStockExchange.Items.Add(StockExchange.FrankfurtStockExchange);
                comboStockExchange.Items.Add(StockExchange.DeutscheBörse);
            }

            else if (comboCountry.SelectedIndex == 0)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.ShanghaiStockExchange);
                comboStockExchange.Items.Add(StockExchange.ShenzhenStockExchange);
            }

            else if (comboCountry.SelectedIndex == 1)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.EuropeanStockExchange);
                comboStockExchange.Items.Add(StockExchange.EuronextParis);
            }

            else if (comboCountry.SelectedIndex == 3)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.HongKongStockExchange);
            }

            else if (comboCountry.SelectedIndex == 5)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.JapanExchangeGroupTokyoNIKKEI);
            }

            else if (comboCountry.SelectedIndex == 6)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.LondonStockExchange);
                comboStockExchange.Items.Add(StockExchange.Euronext);
            }

            else
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.NASDAQ);
                comboStockExchange.Items.Add(StockExchange.NYSE);
            }

        }
    }
}
