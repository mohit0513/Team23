﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MarketAnalysisBasic
{
    /// <summary>
    /// Interaction logic for OtherWindow.xaml
    /// </summary>
    public partial class OtherWindow : Window
    {
        public OtherWindow()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void OpenStockWindow(object sender, RoutedEventArgs e)
        {
            StockWindow stockWindow = new StockWindow();
            stockWindow.Show();
        }

        private void CreateBasket(object sender, RoutedEventArgs e)
        {
            BasketWindow basketWindow = new BasketWindow();
            basketWindow.Show();
        }

        private void FillCountry(object sender, RoutedEventArgs e)
        {
            comboCountry.Items.Add(StockCountry.China);
            comboCountry.Items.Add(StockCountry.France);
            comboCountry.Items.Add(StockCountry.Germany);
            comboCountry.Items.Add(StockCountry.Honkong);
            comboCountry.Items.Add(StockCountry.India);         
            comboCountry.Items.Add(StockCountry.Japan);
            comboCountry.Items.Add(StockCountry.UK);
            comboCountry.Items.Add(StockCountry.USA);

        }

        private void FillSector(object sender, RoutedEventArgs e)
        {
            comboSectors.Items.Add(StockSegment.Automotive);
            comboSectors.Items.Add(StockSegment.BankingAndFinancialServices);
            comboSectors.Items.Add(StockSegment.FoodAndBeverages);
            comboSectors.Items.Add(StockSegment.InformationTechnology);
            comboSectors.Items.Add(StockSegment.Manufacturing);
            comboSectors.Items.Add(StockSegment.MediaAndEntertainment);
            comboSectors.Items.Add(StockSegment.Miscallaneous);
            comboSectors.Items.Add(StockSegment.OilAndGas);
            comboSectors.Items.Add(StockSegment.PSU);
            comboSectors.Items.Add(StockSegment.Services);
            comboSectors.Items.Add(StockSegment.Telecommunication);

        }

        private void StockExchangePerformance(object sender, RoutedEventArgs e)
        {
            // Display performance of the index of the stock exchange by selecting day range
            StockExchangeWindow stockExchangeWindow = new StockExchangeWindow();
            stockExchangeWindow.Show();

        }

        private void SectorPerformance(object sender, RoutedEventArgs e)
        {
            SectorWindow sectorWindow = new SectorWindow();
            sectorWindow.Show();
        }

        private void UpdateStockExchange(object sender, SelectionChangedEventArgs e)
        {

            if (comboCountry.SelectedIndex == 4)
                {
                    comboStockExchange.Items.Clear();
                    comboStockExchange.Items.Add(StockExchange.BombayStockExchangeSENSEX);
                    comboStockExchange.Items.Add(StockExchange.NationalStockExchangeNIFTY);
                }

                else if (comboCountry.SelectedIndex == 2)
                {
                    comboStockExchange.Items.Clear();
                    comboStockExchange.Items.Add(StockExchange.BörseMünchen);
                    comboStockExchange.Items.Add(StockExchange.FrankfurtStockExchange);
                    comboStockExchange.Items.Add(StockExchange.DeutscheBörse);
                }

                else if (comboCountry.SelectedIndex == 0)
                {
                    comboStockExchange.Items.Clear();
                    comboStockExchange.Items.Add(StockExchange.ShanghaiStockExchange);
                    comboStockExchange.Items.Add(StockExchange.ShenzhenStockExchange);
                }

                else if (comboCountry.SelectedIndex == 1)
                {
                    comboStockExchange.Items.Clear();
                    comboStockExchange.Items.Add(StockExchange.EuropeanStockExchange);
                    comboStockExchange.Items.Add(StockExchange.EuronextParis);
                }

                else if (comboCountry.SelectedIndex == 3)
                {
                    comboStockExchange.Items.Clear();
                    comboStockExchange.Items.Add(StockExchange.HongKongStockExchange);
                }

                else if (comboCountry.SelectedIndex == 5)
                {
                    comboStockExchange.Items.Clear();
                    comboStockExchange.Items.Add(StockExchange.JapanExchangeGroupTokyoNIKKEI);
                }

                else if (comboCountry.SelectedIndex == 6)
                {
                    comboStockExchange.Items.Clear();
                    comboStockExchange.Items.Add(StockExchange.LondonStockExchange);
                    comboStockExchange.Items.Add(StockExchange.Euronext);
                }

                else
                {
                    comboStockExchange.Items.Clear();
                    comboStockExchange.Items.Add(StockExchange.NASDAQ);
                    comboStockExchange.Items.Add(StockExchange.NYSE);
                }


        }

        
    }
}
