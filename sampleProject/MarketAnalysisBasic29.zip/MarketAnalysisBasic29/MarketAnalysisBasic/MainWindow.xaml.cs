﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;

namespace MarketAnalysisBasic
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private string filename = "Stock.txt";
        List<StockDetails> stockList = new List<StockDetails>();

        private void OtherWindow(object sender, RoutedEventArgs e)
        {
            OtherWindow newWindow = new OtherWindow();
            newWindow.Show();
        }

        private void WriteJson(object sender, RoutedEventArgs e)
        {
            //StockDetails stockDetail = new StockDetails("ABCD", 567.00, 675.00, 686.00, 569.00, 7234652);
            FileStream filestream = new FileStream(filename, FileMode.Create);

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(StockDetails));
            //serializer.WriteObject(filestream, stockDetail);
            filestream.Close();
        }

        private void ReadJson(object sender, RoutedEventArgs e)
        {
            StreamReader reader = new StreamReader(filename);

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(StockDetails));

            StockDetails other = (StockDetails)serializer.ReadObject(reader.BaseStream);
            MessageBox.Show(other.ToString());
        }

        private void WriteJsonArray(object sender, RoutedEventArgs e)
        {
            StockDetails[] accounts = new StockDetails[]
                {
                    //new StockDetails("ABCDF", 567.00, 675.00,686.00,569.00,7234654),
                   // new StockDetails("ABCDE", 567.00, 675.00,686.00,569.00,7234653)

                };
            FileStream filestream = new FileStream(filename, FileMode.Create);
            DataContractJsonSerializer arrayserializer = new DataContractJsonSerializer(typeof(StockDetails[]));
            arrayserializer.WriteObject(filestream, accounts);
            filestream.Close();
        }

        private void ReadJsonArray(object sender, RoutedEventArgs e)
        {
            StreamReader reader = new StreamReader(filename);
            DataContractJsonSerializer arrayserializer = new DataContractJsonSerializer(typeof(StockDetails[]));

            StockDetails[] stocks = (StockDetails[])arrayserializer.ReadObject(reader.BaseStream);
            string output = "";
            foreach (StockDetails stockDetails in stocks)
                output += stockDetails + "\n";

            MessageBox.Show(output);
        }

        private void ReadString(object sender, RoutedEventArgs e)
        {
            WebClient web = new WebClient();
            string webStream = web.DownloadString("http://192.168.173.3:8080/MarketDataAnalysisWeb/rest/stock");

            //StreamReader reader = new StreamReader(filename);
           // DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(StockDetails));
           // StockDetails other = (StockDetails)serializer.ReadObject(webStream);
            //MessageBox.Show(other.ToString());

            MessageBox.Show(webStream);
        }

        private void WriteString(object sender, RoutedEventArgs e)
        {
            string result = "Hello";
            FileStream filestream = new FileStream(filename, FileMode.Create);

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(string));
            serializer.WriteObject(filestream,result);
            filestream.Close();

            StreamReader stream = new StreamReader(filename);
            string newMessage = (string)serializer.ReadObject(stream.BaseStream);

            WebClient cli = new WebClient();
            string URL = "http://192.168.173.3:8080/MarketDataAnalysisWeb/rest/stock";
            cli.Headers [HttpRequestHeader.ContentType] = "text/plain";
            string response = cli.UploadString(URL,newMessage);
            MessageBox.Show(response);
        }

        /*public Stream GenerateStreamFromString(string s)
        {
            MemoryStream stream = new MemoryStream();
            StreamWriter writer = new StreamWriter(stream);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;

            return stream;
        }*/
   
        private void ReadObject(object sender, RoutedEventArgs e)
        {

            WebClient webClient = new WebClient();

            Stream stream = webClient.OpenRead("http://192.168.173.3:8080/MarketDataAnalysisWeb/rest/stock");

            DataContractJsonSerializer listSerializer = new DataContractJsonSerializer(typeof( List< StockDetails > ) );

            List < StockDetails > stocks = ( List < StockDetails > ) listSerializer.ReadObject(stream);

            string output = "";

            MessageBox.Show("Hello\n");
            foreach (StockDetails stock in stocks)
            {
                //stock.Date = DateTime.Parse(stock.date);
                output += stock.ToString() + "\n";
                stockList.Add(stock);
                //stockListing.Items.Add(stock);
            }

            MessageBox.Show(output);
                
        }

        private void WriteObject(object sender, RoutedEventArgs e)
        {
                   
            FileStream filestream = new FileStream(filename, FileMode.Create);

            DataContractJsonSerializer serializerList = new DataContractJsonSerializer( typeof ( List < StockDetails > ) );
            serializerList.WriteObject(filestream, stockList);
            filestream.Close();
            

            // Now Send This File to the Server just like sending a string.

            string result = "";
            StreamReader Sr = new StreamReader(filename);

            while (Sr.Peek() > -1)
            {
                result += Sr.ReadLine() + "\n";
            }

            Sr.Close();
            FileStream newFileStream = new FileStream(filename, FileMode.Create);

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(string));
            serializer.WriteObject(newFileStream, result);
            newFileStream.Close();

            StreamReader stream = new StreamReader(filename);
            string newMessage = (string)serializer.ReadObject(stream.BaseStream);

            WebClient cli = new WebClient();
            string URL = "http://192.168.173.3:8080/MarketDataAnalysisWeb/rest/stock";

            cli.Headers[HttpRequestHeader.ContentType] = "text/plain";
            string response = cli.UploadString(URL, newMessage);

            MessageBox.Show(response);
   
        }

        private void CheckDate(object sender, RoutedEventArgs e)
        {
            Check check = new Check();
            check.Date = DateTime.Now;

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(Check));
            FileStream filestream = new FileStream(filename, FileMode.Create);
            serializer.WriteObject(filestream,check);
            filestream.Close();

        }

        private void AddDetails(object sender, RoutedEventArgs e)
        {
            dataStockTable.ItemsSource = stockList;
        }

        private void OpenStockWindow(object sender, RoutedEventArgs e)
        {
            StockWindow stockWindow = new StockWindow();
            stockWindow.Show();
        }

        private void CreateBasket(object sender, RoutedEventArgs e)
        {
            BasketWindow basketWindow = new BasketWindow();
            basketWindow.Show();
        }

        private void FillCountry(object sender, RoutedEventArgs e)
        {
            comboCountry.Items.Add(StockCountry.China);
            comboCountry.Items.Add(StockCountry.France);
            comboCountry.Items.Add(StockCountry.Germany);
            comboCountry.Items.Add(StockCountry.Honkong);
            comboCountry.Items.Add(StockCountry.India);
            comboCountry.Items.Add(StockCountry.Japan);
            comboCountry.Items.Add(StockCountry.UK);
            comboCountry.Items.Add(StockCountry.USA);

        }

        private void FillSector(object sender, RoutedEventArgs e)
        {
            comboSectors.Items.Add(StockSegment.Automotive);
            comboSectors.Items.Add(StockSegment.BankingAndFinancialServices);
            comboSectors.Items.Add(StockSegment.FoodAndBeverages);
            comboSectors.Items.Add(StockSegment.InformationTechnology);
            comboSectors.Items.Add(StockSegment.Manufacturing);
            comboSectors.Items.Add(StockSegment.MediaAndEntertainment);
            comboSectors.Items.Add(StockSegment.Miscallaneous);
            comboSectors.Items.Add(StockSegment.OilAndGas);
            comboSectors.Items.Add(StockSegment.PSU);
            comboSectors.Items.Add(StockSegment.Services);
            comboSectors.Items.Add(StockSegment.Telecommunication);

        }

        private void StockExchangePerformance(object sender, RoutedEventArgs e)
        {
            // Display performance of the index of the stock exchange by selecting day range
            StockExchangeWindow stockExchangeWindow = new StockExchangeWindow();
            stockExchangeWindow.Show();

        }

        private void SectorPerformance(object sender, RoutedEventArgs e)
        {
            SectorWindow sectorWindow = new SectorWindow();
            sectorWindow.Show();
        }

        private void UpdateStockExchange(object sender, SelectionChangedEventArgs e)
        {

            if (comboCountry.SelectedIndex == 4)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.BombayStockExchangeSENSEX);
                comboStockExchange.Items.Add(StockExchange.NationalStockExchangeNIFTY);
            }

            else if (comboCountry.SelectedIndex == 2)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.BörseMünchen);
                comboStockExchange.Items.Add(StockExchange.FrankfurtStockExchange);
                comboStockExchange.Items.Add(StockExchange.DeutscheBörse);
            }

            else if (comboCountry.SelectedIndex == 0)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.ShanghaiStockExchange);
                comboStockExchange.Items.Add(StockExchange.ShenzhenStockExchange);
            }

            else if (comboCountry.SelectedIndex == 1)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.EuropeanStockExchange);
                comboStockExchange.Items.Add(StockExchange.EuronextParis);
            }

            else if (comboCountry.SelectedIndex == 3)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.HongKongStockExchange);
            }

            else if (comboCountry.SelectedIndex == 5)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.JapanExchangeGroupTokyoNIKKEI);
            }

            else if (comboCountry.SelectedIndex == 6)
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.LondonStockExchange);
                comboStockExchange.Items.Add(StockExchange.Euronext);
            }

            else
            {
                comboStockExchange.Items.Clear();
                comboStockExchange.Items.Add(StockExchange.NASDAQ);
                comboStockExchange.Items.Add(StockExchange.NYSE);
            }


        }

        private void Search(object sender, RoutedEventArgs e)
        {
            if (listStock.Contains(txtSearch.Text))
            {
                
            }

            else
            {
                MessageBox.Show("Stock Not Found");
            }
        }
    }
}