﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;

namespace MarketAnalysisBasic
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private string filename = "Stock.txt";

        private void WriteJson(object sender, RoutedEventArgs e)
        {
            //StockDetails stockDetail = new StockDetails("ABCD", 567.00, 675.00, 686.00, 569.00, 7234652);
            FileStream filestream = new FileStream(filename, FileMode.Create);

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(StockDetails));
            //serializer.WriteObject(filestream, stockDetail);
            filestream.Close();
        }

        private void ReadJson(object sender, RoutedEventArgs e)
        {
            StreamReader reader = new StreamReader(filename);

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(StockDetails));

            StockDetails other = (StockDetails)serializer.ReadObject(reader.BaseStream);
            MessageBox.Show(other.ToString());
        }

        private void WriteJsonArray(object sender, RoutedEventArgs e)
        {
            StockDetails[] accounts = new StockDetails[]
                {
                    //new StockDetails("ABCDF", 567.00, 675.00,686.00,569.00,7234654),
                   // new StockDetails("ABCDE", 567.00, 675.00,686.00,569.00,7234653)

                };
            FileStream filestream = new FileStream(filename, FileMode.Create);
            DataContractJsonSerializer arrayserializer = new DataContractJsonSerializer(typeof(StockDetails[]));
            arrayserializer.WriteObject(filestream, accounts);
            filestream.Close();
        }

        private void ReadJsonArray(object sender, RoutedEventArgs e)
        {
            StreamReader reader = new StreamReader(filename);
            DataContractJsonSerializer arrayserializer = new DataContractJsonSerializer(typeof(StockDetails[]));

            StockDetails[] stocks = (StockDetails[])arrayserializer.ReadObject(reader.BaseStream);
            string output = "";
            foreach (StockDetails stockDetails in stocks)
                output += stockDetails + "\n";

            MessageBox.Show(output);
        }

        private void ReadString(object sender, RoutedEventArgs e)
        {
            WebClient web = new WebClient();
            string webStream = web.DownloadString("http://192.168.173.1:8080/StudentOnlineRetailerWeb/rest/product");

            StreamReader reader = new StreamReader(filename);
           // DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(StockDetails));
           // StockDetails other = (StockDetails)serializer.ReadObject(webStream);
            //MessageBox.Show(other.ToString());



            MessageBox.Show(webStream);
        }

        private void WriteString(object sender, RoutedEventArgs e)
        {

            var cli = new WebClient();
            string URL = "http://192.168.66.53:8080/EBondTraderWeb/rest/EBond";
            cli.Headers [HttpRequestHeader.ContentType] = "text/plain";
            string response = cli.UploadString(URL,"Hello");
            MessageBox.Show(response);
        }

        public Stream GenerateStreamFromString(string s)
        {
            MemoryStream stream = new MemoryStream();
            StreamWriter writer = new StreamWriter(stream);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;

            return stream;
        }

        private void ReadObject(object sender, RoutedEventArgs e)
        {

            WebClient web = new WebClient();

            List<StockDetails> stockList = new List<StockDetails>();

            string result = web.DownloadString("http://192.168.173.3:8080/MarketDataAnalysisWeb/rest/stock");

            DataContractJsonSerializer listSerializer = new DataContractJsonSerializer(typeof( List< StockDetails >));

            Stream stream = GenerateStreamFromString(result);
            //StockDetails stock = (StockDetails)arrayserializer.ReadObject(stream);

            List < StockDetails > stocks = (List < StockDetails >)listSerializer.ReadObject(stream);

            string output = "";

            foreach (StockDetails stock in stocks)
            {
                output += stock.ToString() + "\n";
                stockListing.Items.Add(stock);
            }

            MessageBox.Show(output);
                
        }

        

    }
}