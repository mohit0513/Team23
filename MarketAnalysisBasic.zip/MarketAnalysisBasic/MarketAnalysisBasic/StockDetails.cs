﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Json;
using System.Runtime.Serialization;

namespace MarketAnalysisBasic
{

    enum StockSegment
    {
        Automotive,
        BankingAndFinancialServices,
        Telecommunication,
        InformationTechnology,
        Manufacturing,
        FoodAndBeverages,
        OilAndGas,
        Miscallaneous,
        PSU,
        Services,
        MediaAndEntertainment
    };

    enum StockCountry
    {
        India,
        Usa,
        UK,
        Germany,
        France,
        Japan,
        China,
        Honkong
    };

    enum StockMarketIndia
    {
        NationalStockExchangeNIFTY,
        BombayStockExchangSENSEX
    };

    enum StockMarketUsa
    {
        NYSE,
        NASDAQ
    };

    enum StockMarketUk
    {
        LondonStockExchange,
        Euronext
    };

    enum StockMarketHonkong
    {
        HongKongStockExchange
    };

    enum StockMarketChina
    {
        ShanghaiStockExchange,
        ShenzhenStockExchange
    };

    enum StockMarketJapan
    {
        JapanExchangeGroupTokyoNIKKEI
    };

    enum StockMarketGermany
    {
        DeutscheBörse,
        BörseMünchen,
        FrankfurtStockExchange
    };

    enum StockMarketFrance
    {
        EuronextParis,
        EuropeanStockExchange
    };

    enum StockExchange
    {
        NationalStockExchangeNIFTY,
        BombayStockExchangSENSEX,
        NYSE,
        NASDAQ,
        LondonStockExchange,
        Euronext,
        HongKongStockExchange,
        ShanghaiStockExchange,
        ShenzhenStockExchange,
        JapanExchangeGroupTokyoNIKKEI,
        DeutscheBörse,
        BörseMünchen,
        FrankfurtStockExchange,
        EuronextParis,
        EuropeanStockExchange
    };

    [DataContract]
    class StockDetails
    {
        [DataMember]
        public string Ticker { get; private set; }
        [DataMember]
        public int UniqueStockId { get; private set; }
        [DataMember]
        public double Open { get; private set; }
        [DataMember]
        public double Close { get; private set; }
        [DataMember]
        public double High { get; private set; }
        [DataMember]
        public double Low { get; private set; }
        [DataMember]
        public DateTime Date { get; private set; }
        [DataMember]
        public StockSegment Sector { get; private set; }
        [DataMember]
        public StockCountry Country { get; private set; }
        [DataMember]
        public StockExchange Exchange { get; private set; }
        [DataMember]
        public double ValueWeightedAveragePrice { get; private set; }
        [DataMember]
        public double TradedVolume { get; private set; }
        [DataMember]
        public long TradedPrice { get; private set; }
        [DataMember]
        public long FreeFloatMarketCap { get; private set; }
        [DataMember]
        public double YearHigh { get; private set; }
        [DataMember]
        public double YearLow { get; private set; }
        [DataMember]
        public int BuyQuantity { get; private set; }
        [DataMember]
        public int SellQuantitiy { get; private set; }
        [DataMember]
        public double BuyPrice { get; private set; }
        [DataMember]
        public double SellPrice { get; private set; }


        public StockDetails( string ticker, DateTime date,double openPrice, double closePrice, double highestPrice, double lowestPrice, double tradedVolume, int uniqueStockId)
        {

            Ticker = ticker;
            Open = openPrice;
            Close = closePrice;
            High = highestPrice;
            Low = lowestPrice;
            UniqueStockId = uniqueStockId;
            Date = date;
            TradedVolume = tradedVolume;
        }


        public override string ToString()
        {
            string message ="StockId : " + UniqueStockId +"\nTicker : " + Ticker + "\n Date Time : " + Date + "\nOpen Price"  + Open + "\nClose Price : " + Close + "\nHighest IntraDay Price : "
                + High + "\nLowestIntraDay Price : " + Low + "\nTraded Volume : " + TradedVolume;
            message += "";

            return message;
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            if (obj is StockDetails)
            {
                StockDetails p = obj as StockDetails;
                return Exchange == p.Exchange && Ticker == p.Ticker;
            }

            return false;
        }

    }
}
