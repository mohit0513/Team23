﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Net;
using System.IO;
using System.Runtime.Serialization.Json;



namespace MarketAnalysisBasic
{
    /// <summary>
    /// Interaction logic for PeerComparison.xaml
    /// </summary>
    public partial class PeerComparison : Window
    {
        public PeerComparison()
        {
            InitializeComponent();
        }
       
      //public static List<KeyValuePair<DateTime, double>> intelPrices2 = new List<KeyValuePair<DateTime, double>>();
      //public  static List<KeyValuePair<DateTime, double>> intelPrices3 = new List<KeyValuePair<DateTime, double>>();


        private void LastNumberOfDays(object sender, RoutedEventArgs e)
        {
            comboSelectRange.Items.Add("7 Days");
            comboSelectRange.Items.Add("2 Weeks");
            comboSelectRange.Items.Add("30 Days");
            comboSelectRange.Items.Add("6 Months");
            comboSelectRange.Items.Add("1 Years");
            comboSelectRange.Items.Add("5 Years");
            comboSelectRange.Items.Add("10 Years");
        }

        private void CompareStockExchange(object sender, RoutedEventArgs e)
        {
            // Compare the stocks performance with the performance of the stock exchange on which it is listed
            // over a range of time.Show their performance graph.
        }

        private void ComapreSectorPerformance(object sender, RoutedEventArgs e)
        {
            // Compare the stocks performance with the performance of the sector in which it belongs
            // over a range of time.Show their performance graph.
        }

        private void CompreSectorStocks(object sender, RoutedEventArgs e)
        {
            // Add all the stocks belonging to that sector listed on that particular stock exchange
            /*comboSectorStocks.Items.Add();
            comboSectorStocks.Items.Add();
            comboSectorStocks.Items.Add();
            comboSectorStocks.Items.Add();
            comboSectorStocks.Items.Add();
            comboSectorStocks.Items.Add();
            */
        }

        private void Multiple(object sender, RoutedEventArgs e)
        {
  
            string value1 = (string)txtSearch.Text;
            string value2 = (string)comboexchange.SelectedItem;

            WebClient webClient = new WebClient();

            DateTime d = (DateTime)(dtpCompareStart.SelectedDate);
            string value3 = d.ToString("yyyyMMdd");

            d = (DateTime)(dtpCompareEnd.SelectedDate);
            string value4 = d.ToString("yyyyMMdd");

            //MessageBox.Show(value1,value2,value3,value4);

            Stream newStream1 = webClient.OpenRead("http://192.168.173.3:8080/MarketDataAnalysisWeb/rest/stock/stockhistoryver/" + value1 + "/" + value2 + "/" + value3 + "/" + value4 + "");
            value2 = "NASDAQ";
            value1 = txtStock.Text;
            MessageBox.Show(value1.ToString());

            Stream newStream = webClient.OpenRead("http://192.168.173.3:8080/MarketDataAnalysisWeb/rest/stock/stockhistoryver/" + value1 + "/" + value2 + "/" + value3 + "/" + value4 + "");

            DataContractJsonSerializer listSerializer = new DataContractJsonSerializer(typeof(List<StockDetails>));

            List<StockDetails> stocks = (List<StockDetails>)listSerializer.ReadObject(newStream);

            List<StockDetails> stocks1 = (List<StockDetails>)listSerializer.ReadObject(newStream1);



            foreach (StockDetails stock in stocks)
            {
                //stock.ToString();
                DateTime Datadate = DateTime.ParseExact(stock.date, "yyyy-MM-dd", null);

                App.intelPrices2.Add(new KeyValuePair<DateTime, double>(Datadate, stock.close));

            }

            foreach (StockDetails stock in stocks1)
            {
                //stock.ToString();
                DateTime Datadate = DateTime.ParseExact(stock.date, "yyyy-MM-dd", null);

                App.intelPrices3.Add(new KeyValuePair<DateTime, double>(Datadate, stock.close));

            }

            NewWindow GraphCompare = new NewWindow();

            //GraphCompare.listBox.It

            GraphCompare.Show();
            return;

        }

        private void SearchStock(object sender, RoutedEventArgs e)
        {

            string value1 = txtSearch.Text;

            WebClient webClient = new WebClient();

            Stream newStream = webClient.OpenRead("http://192.168.173.3:8080/MarketDataAnalysisWeb/rest/stock/search/" + value1 + "");

            DataContractJsonSerializer listSerializer = new DataContractJsonSerializer(typeof(List<StockDetails>));

            List<StockDetails> stocks = (List<StockDetails>)listSerializer.ReadObject(newStream);

            if (stocks.Count == 0)
            {
                MessageBox.Show("No Matching Stock");
                return;
            }

            comboexchange.Items.Clear();

            foreach (StockDetails stock in stocks)
            {
                comboexchange.Items.Add(stock.exchangemarket);
            }

            return;

        }
    }
}
