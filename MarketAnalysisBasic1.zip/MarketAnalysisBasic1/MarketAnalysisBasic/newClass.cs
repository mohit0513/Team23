﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketAnalysisBasic
{

    public class newClass
    {
        public string Ticker;
        public double weights;
        public string exchange;

        public newClass(string s, double s1, string s2)
        {
            this.Ticker = s;
            this.weights = s1;
            this.exchange = s2;
        }


        public override string ToString()
        {
            string msg = "";

            msg += "Ticker : " + Ticker + "  Exchange Market : " + exchange + " Weight  : " + weights;

            return msg;
        }
    }
}
