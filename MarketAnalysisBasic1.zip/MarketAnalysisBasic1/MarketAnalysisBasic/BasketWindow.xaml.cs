﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows;
using System.Windows.Controls;
using System.Net;
using System.IO;
using System.Runtime.Serialization.Json;


namespace MarketAnalysisBasic
{
    /// <summary>
    /// Interaction logic for BasketWindow.xaml
    /// </summary>
    public partial class BasketWindow : Window
    {
        string[] array = new string[17];

        public static List<KeyValuePair<DateTime, double>> intelPrices1 = new List<KeyValuePair<DateTime, double>>();


        public BasketWindow()
        {
            InitializeComponent();
        }

        int i = 0;

        private void Basket(object sender, RoutedEventArgs e)
        {

            DateTime d = (DateTime)(dtpStart.SelectedDate);
            array[10] = d.ToString("yyyyMMdd");

            d = (DateTime)(dtpEnd.SelectedDate);
            array[11] = d.ToString("yyyyMMdd");

            
            
            WebClient webClient = new WebClient();

            for (int j = 0; j < 5; j ++)
            {
                array[ 2*j + 1 ] = "NASDAQ";
                array[ 2*j ] = "AAON";
            }

            //array[10] =;

            for (int j = 0; j < 5; j++)
            {
                array[j+12]=(0.2).ToString();
            }

            //List<newClass> lst = new List<newClass>();
            //List<newClass> newlist = new List<newClass>();
            for (int j = 0; j < 5; j++)
            {

                //MessageBox.Show(array[2*j]); 
                lstBasketItems.Items.Add(new newClass(array[2*j],(double.Parse)(array[j + 12]),(array[2*j + 1])).ToString());
            }

            

            Stream stream = webClient.OpenRead("http://192.168.173.3:8080/MarketDataAnalysisWeb/rest/stock/stockbasket/" + array[0] + "/" + array[1] + "/" + array[2] + "/" + array[3] + "/" + array[4] + "/" + array[5] + "/" + array[6] + "/" + array[7] + "/" + array[8] + "/" + array[9] + "/" + array[10] + "/" + array[11] + "/" + array[12] + "/" + array[13] + "/" + array[14] + "/" + array[15] + "/" + array[16] + "");

            DataContractJsonSerializer listSerializer = new DataContractJsonSerializer(typeof(List<StockDetails>));

            List<StockDetails> stocks = (List<StockDetails>)listSerializer.ReadObject(stream);
           //// MessageBox.Show("Hello\n");
           // int x=stocks.Count;
           // MessageBox.Show(x.ToString());

            foreach (StockDetails stock in stocks)
            {
                //stock.ToString();
                DateTime Datadate = DateTime.ParseExact(stock.date, "yyyy-MM-dd", null);

                intelPrices1.Add(new KeyValuePair<DateTime, double>(Datadate, stock.close));

            }
            lineseries.ItemsSource = intelPrices1;

            return;

        }

        private void AddStocks(object sender, RoutedEventArgs e)
        {

            string value1 = txtSearch.Text;

            if (i == 5)
            {
                MessageBox.Show("Maximum Limit exceeded");
                return;
            }
                
                WebClient webClient = new WebClient();

                Stream newStream = webClient.OpenRead("http://192.168.173.3:8080/MarketDataAnalysisWeb/rest/stock/search/" + value1 + "");

                DataContractJsonSerializer listSerializer = new DataContractJsonSerializer(typeof(List<StockDetails>));

                List<StockDetails> stocks = (List<StockDetails>)listSerializer.ReadObject(newStream);

            if (stocks.Count == 0)
            {
                MessageBox.Show("No Matching Stock");
                return;
            }

            comboStock.Items.Clear();

            foreach (StockDetails stock in stocks)
                {
                    comboStock.Items.Add(stock.exchangemarket);
                }
 
                i ++;
          
                return;
        }

        private void Select(object sender, RoutedEventArgs e)
        {

            StockDetails newstock = new StockDetails((string)comboStock.SelectedItem, (string)txtSearch.Text);
            array[i + 11] = (string)txtStockWeights.Text;
            //lstWeights.Items.Add((string)txtStockWeights.Text);
            txtStockWeights.Text = "";

            List<StockDetails> newStockList = new List<StockDetails>();

            string value1 = (string)txtSearch.Text;
            txtSearch.Text = "";
            string value2 = (string)comboStock.SelectedItem;
            comboStock.Items.Clear();

            WebClient webClient = new WebClient();

            array[2 * i - 2] = value1;
            //MessageBox.Show(array[2 * i - 2]);
            array[2 * i - 1] = value2;

            Stream newStream = webClient.OpenRead("http://192.168.173.3:8080/MarketDataAnalysisWeb/rest/stock/test/" + value2 + "/" + value1 + "");

            DataContractJsonSerializer listSerializer = new DataContractJsonSerializer(typeof(List<StockDetails>));

            List<StockDetails> stocks = (List<StockDetails>)listSerializer.ReadObject(newStream);

            foreach (StockDetails stock in newStockList)
            {
                stock.Date = DateTime.ParseExact(stock.date, "yyyy-MM-dd", null);
                intelPrices1.Add(new KeyValuePair<DateTime, double>(stock.Date, stock.close));
            }
     
        }


    }
}
