﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MarketAnalysisBasic
{
    /// <summary>
    /// Interaction logic for SectorWindow.xaml
    /// </summary>
    public partial class SectorWindow : Window
    {
        public SectorWindow()
        {
            InitializeComponent();
        }

        private void Compare(object sender, RoutedEventArgs e)
        {
            comboComapre.Items.Add("Basic Industries");
            comboComapre.Items.Add("Capital Goods");
            comboComapre.Items.Add("Consumer Durables");
            comboComapre.Items.Add("Consumer Non Durables");
            comboComapre.Items.Add("Consumer Services");
            comboComapre.Items.Add("Energy");
            comboComapre.Items.Add("Finance");
            comboComapre.Items.Add("Health Care");
            comboComapre.Items.Add("Miscellaneous");
            comboComapre.Items.Add("Public Utilities");
            comboComapre.Items.Add("Technology");
            comboComapre.Items.Add("Transportation");
        }

        private void SectorPerformers(object sender, RoutedEventArgs e)
        {
            comboSectorPerformers.Items.Add("ActivelyTraded");
            comboSectorPerformers.Items.Add("EPS");
            comboSectorPerformers.Items.Add("Gainers");
            comboSectorPerformers.Items.Add("Losers");
            comboSectorPerformers.Items.Add("MarketCap");
            comboSectorPerformers.Items.Add("PBRatio");
            comboSectorPerformers.Items.Add("PERatio");
            comboSectorPerformers.Items.Add("Return");
            comboSectorPerformers.Items.Add("Revenue");
            comboSectorPerformers.Items.Add("Stability");
            comboSectorPerformers.Items.Add("Volatility");
        }

        private void LastNumberOfDays(object sender, RoutedEventArgs e)
        {
            comboSelectRange.Items.Add("7 Days");
            comboSelectRange.Items.Add("2 Weeks");
            comboSelectRange.Items.Add("30 Days");
            comboSelectRange.Items.Add("6 Months");
            comboSelectRange.Items.Add("1 Years");
            comboSelectRange.Items.Add("5 Years");
            comboSelectRange.Items.Add("10 Years");
        }

        private void CompareSectorPerformance(object sender, ContextMenuEventArgs e)
        {
            //// Compare the performance of the 2 sectors over a certain range of time
            // Also Plot the graph.


        }

        private void ShowTopPerformers(object sender, RoutedEventArgs e)
        {
            // Show the top stocks corresponding to the selected criteria over a certain range of time.
            // Also Plot the graphs.


        }
    }
}
